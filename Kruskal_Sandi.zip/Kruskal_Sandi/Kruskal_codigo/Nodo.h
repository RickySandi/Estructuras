#pragma once
#include<iostream>
#include<string>
using namespace std;
template<class T>
class Nodo
{
private:
	T elemento;
	Nodo<T> *siguiente;
	Nodo<T> *anterior;
	int peso;
public:
	Nodo();
	~Nodo();
	Nodo<T>* getSiguiente();
	Nodo<T>* getAnterior();
	void setSiguiente(Nodo* nuevo);
	void setAnterior(Nodo* nuevo);
	void setElemento(T elem);
	T getElem();
	Nodo<T>* getThis();
	void setPeso(int peso);
	int getPeso();
};
template<class T>
Nodo<T>::Nodo()
{
	siguiente = NULL;
	anterior = NULL;
}
template<class T>
Nodo<T>::~Nodo()
{

}
template<class T>
Nodo<T>* Nodo<T>::getSiguiente()
{
	return siguiente;
}
template<class T>
Nodo<T>* Nodo<T>::getAnterior()
{
	return anterior;
}
template<class T>
void Nodo<T>::setAnterior(Nodo<T>* nuevo)
{
	anterior = nuevo;
}
template<class T>
void Nodo<T>::setSiguiente(Nodo<T>* nuevo)
{
	siguiente = nuevo;
}
template<class T>
void Nodo<T>::setElemento(T elem)
{
	elemento = elem;
}
template<class T>
T Nodo<T>::getElem()
{
	return elemento;
}
template<class T>
Nodo<T>* Nodo<T>::getThis()
{
	return this;
}
template<class T>
void Nodo<T>::setPeso(int peso)
{
	this->peso = peso;
}
template<class T>
int Nodo<T>::getPeso()
{
	return peso;
}