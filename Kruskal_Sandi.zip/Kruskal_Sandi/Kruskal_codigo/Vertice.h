#pragma once
#include"Lista8.h"
template<class T>
class Vertice
{
private:
	T nombre;
	string nombreDep;
	bool marca;
	Lista8<T>lista;
	int padre;
	bool existe;
	int distancia;
public:
	Vertice();
	~Vertice();
	void setNombre(T nombre);
	void setMarca(bool marca);
	void setPadre(int padre);
	T getNombre();
	bool getMarca();
	int getPadre();
	void insertarFinalLista8(T elemento,int peso);
	void mostrarLista8();
	void setExiste(bool existe);
	bool getExiste();
	Nodo<T>* sacarSiguienteAdyacente(int i_esimo);
	int getCont();
	void setDistancia(int distancia);
	int getDistancia();
	void setNombreDep(string nombre);
	string getNombreDep(); 

};
template<class T>
Vertice<T>::Vertice()
{
	marca = false;
	padre = -1;
	existe = false;
	distancia = 10000;
}
template<class T>
Vertice<T>::~Vertice()
{

}
template<class T>
void Vertice<T>::setNombre(T nombre)
{
	this->nombre = nombre;
}
template<class T>
void Vertice<T>::setMarca(bool marca)
{
	this->marca = marca;
}
template<class T>
void Vertice<T>::setPadre(int padre)
{
	this->padre = padre;
}
template<class T>
T Vertice<T>::getNombre()
{
	return nombre;
}
template<class T>
bool Vertice<T>::getMarca()
{
	return marca;
}
template<class T>
int Vertice<T>::getPadre()
{
	return padre;
}
template<class T>
void Vertice<T>::insertarFinalLista8(T elemento,int peso)
{
	lista.insertarFinal(elemento,peso);
}
template<class T>
void Vertice<T>::mostrarLista8()
{
	lista.mostrar();
}
template<class T>
void Vertice<T>::setExiste(bool existe)
{
	this->existe = existe;
}
template<class T>
bool Vertice<T>::getExiste()
{
	return existe;
}
template<class T>
 Nodo<T>* Vertice<T>::sacarSiguienteAdyacente(int i_esimo)
{
	Nodo<T>*aux=lista.sacarSiguienteAdyacente(i_esimo);
	return aux;
}
template<class T>
int Vertice<T>::getCont()
{
	return lista.contarElementos();
}
template<class T>
void Vertice<T>::setDistancia(int distancia)
{
	this->distancia = distancia;
}
template<class T>
int Vertice<T>::getDistancia()
{
	return distancia;
}
template<class T>
void Vertice<T>::setNombreDep(string nombreDep)
{
	this->nombreDep = nombreDep;
}
template<class T>
string Vertice<T>::getNombreDep()
{
	return nombreDep;
}
