#pragma once
#include "NodoArbol.h"
#include<fstream>
#include<vector>
#define TAM 30000
template<class T>
class ArbolBinarioMonticulo
{
private:
	NodoArbol<T> vec[TAM];
	int raiz;
	int ultimaHoja;
	ifstream archivo;
public:
	ArbolBinarioMonticulo();
	~ArbolBinarioMonticulo();
	void insertar(T elemento, T verticeOrigen, T verticeDestino);
	void recuperarAbajoArriba(int pos);
	void recuperarArribaAbajo(int pos);
	T eliminarMayor(int pos);
	void recorrerInOrder(int pos);
	void recorrerPreOrder(int pos);
	void recorrerPostOrder(int pos);
	int calcularAltura(int pos);
	int contarNodoArbols(int pos);
	int contarHojas(int pos);
	bool leerArchivo(string nomArch);
	void menu();
	void ordenar(int pos);
	void ordenar2(int pos);
	NodoArbol<T> getRaiz();
	NodoArbol<T> sacarRaiz();
	//void mostrarOrdenado(int pos);
};
template<class T>
ArbolBinarioMonticulo<T>::ArbolBinarioMonticulo()
{
	raiz = 1;
}
template<class T>
ArbolBinarioMonticulo<T>::~ArbolBinarioMonticulo()
{

}
template<class T>
void ArbolBinarioMonticulo<T>::insertar(T elemento, T verticeOrigen,T verticeDestino)
{
	if (vec[1].getPresente() == false)
	{
		ultimaHoja = 1;
		vec[ultimaHoja].setElemento(elemento);
		vec[ultimaHoja].setVerticeOrigen(verticeOrigen);
		vec[ultimaHoja].setVerticeDestino(verticeDestino);
		vec[ultimaHoja].setPresente(true);
	}
	else
	{
		ultimaHoja = ultimaHoja + 1;
		vec[ultimaHoja].setElemento(elemento);
		vec[ultimaHoja].setVerticeOrigen(verticeOrigen);
		vec[ultimaHoja].setVerticeDestino(verticeDestino);
		vec[ultimaHoja].setPresente(true);
		recuperarAbajoArriba(ultimaHoja);
	}
}
template<class T>
inline void ArbolBinarioMonticulo<T>::recuperarAbajoArriba(int pos)
{
	T aux,verticeOrigen,verticeDestino;
	if (vec[pos / 2].getPresente() == true)
	{
		if (vec[pos].getElemento() < vec[pos / 2].getElemento())
		{
			aux = vec[pos / 2].getElemento();
			verticeOrigen = vec[pos / 2].getVerticeOrigen();
			verticeDestino = vec[pos / 2].getVerticeDestino();
			vec[pos / 2].setElemento(vec[pos].getElemento());
			vec[pos / 2].setVerticeOrigen(vec[pos].getVerticeOrigen());
			vec[pos / 2].setVerticeDestino(vec[pos].getVerticeDestino());
			vec[pos].setElemento(aux);
			vec[pos].setVerticeOrigen(verticeOrigen);
			vec[pos].setVerticeDestino(verticeDestino);
			recuperarAbajoArriba(pos / 2);
		}
	}
}
template<class T>
void ArbolBinarioMonticulo<T>::recuperarArribaAbajo(int pos)
{
	T aux, verticeOrigen, verticeDestino;
	if (vec[pos*2].getPresente() != false && vec[2*pos+1].getPresente() != false)
	{
		if (vec[pos].getElemento() >vec[2*pos].getElemento() || vec[pos].getElemento() > vec[2 * pos + 1].getElemento())
		{
			if (vec[2 * pos].getElemento() < vec[2 * pos + 1].getElemento())
			{
				aux=vec[pos].getElemento();
				verticeOrigen = vec[pos].getVerticeOrigen();
				verticeDestino = vec[pos].getVerticeDestino();
				vec[pos].setElemento(vec[pos * 2].getElemento());
				vec[pos].setVerticeOrigen(vec[pos * 2].getVerticeOrigen());
				vec[pos].setVerticeDestino(vec[pos * 2].getVerticeDestino());
				vec[pos * 2].setElemento(aux);
				vec[pos * 2].setVerticeOrigen(verticeOrigen);
				vec[pos * 2].setVerticeDestino(verticeDestino);
				recuperarArribaAbajo(pos * 2);
			}
			else
			{
				aux = vec[pos].getElemento();
				verticeOrigen = vec[pos].getVerticeOrigen();
				verticeDestino = vec[pos].getVerticeDestino();
				vec[pos].setElemento(vec[pos * 2 + 1].getElemento());
				vec[pos].setVerticeOrigen(vec[pos * 2+1].getVerticeOrigen());
				vec[pos].setVerticeDestino(vec[pos * 2+1].getVerticeDestino());
				vec[pos * 2 + 1].setElemento(aux);
				vec[pos * 2+1].setVerticeOrigen(verticeOrigen);
				vec[pos * 2+1].setVerticeDestino(verticeDestino);
				recuperarArribaAbajo(pos * 2 + 1);
			}
		}
	}
	else if (vec[pos * 2].getPresente() != false)
	{

		aux = vec[pos].getElemento();
		verticeOrigen = vec[pos].getVerticeOrigen();
		verticeDestino = vec[pos].getVerticeDestino();
		vec[pos].setElemento(vec[pos * 2].getElemento());
		vec[pos].setVerticeOrigen(vec[pos * 2].getVerticeOrigen());
		vec[pos].setVerticeDestino(vec[pos * 2].getVerticeDestino());
		vec[pos * 2].setElemento(aux);
		vec[pos * 2].setVerticeOrigen(verticeOrigen);
		vec[pos * 2].setVerticeDestino(verticeDestino);
		recuperarArribaAbajo(pos * 2);
	}
}
template<class T>
T ArbolBinarioMonticulo<T>::eliminarMayor(int pos)
{
	T mayor;
	if (vec[pos].getPresente() == false)
	{
		mayor = NULL;
	}
	else
	{
		mayor = vec[1].getElemento();
		vec[1].setElemento(vec[ultimaHoja].getElemento());
		vec[ultimaHoja].setPresente(false);
		ultimaHoja = ultimaHoja - 1;
		recuperarArribaAbajo(1);
	}
	return mayor;
}
template<class T>
void ArbolBinarioMonticulo<T>::recorrerInOrder(int pos)
{
	if (vec[pos].getPresente() == false)
	{

	}
	else
	{
		recorrerInOrder(2 * pos);
		cout << vec[pos].getElemento() << " ";
		recorrerInOrder(2 * pos + 1);
	}
}

template<class T>
inline void ArbolBinarioMonticulo<T>::recorrerPreOrder(int pos)
{
	if (vec[pos].getPresente() == false)
	{

	}
	else
	{
		cout << vec[pos].getElemento() << " ";
		recorrerPreOrder(2 * pos);
		recorrerPreOrder(2 * pos + 1);
	}
}
template<class T>
void ArbolBinarioMonticulo<T>::recorrerPostOrder(int pos)
{
	if (vec[pos].getPresente() == false)
	{

	}
	else
	{
		recorrerPostOrder(2 * pos);
		recorrerPostOrder(2 * pos + 1);
		cout << vec[pos].getElemento() << " ";
	}
}
template<class T>
inline int ArbolBinarioMonticulo<T>::calcularAltura(int pos)
{
	if (vec[pos].getPresente() == false)
	{
		return 0;
	}
	else
	{
		int a, b;
		a = calcularAltura(pos * 2);
		b = calcularAltura(pos * 2 + 1);
		if (a > b)
			return a + 1;
		else
			return b + 1;
	}
}

template<class T>
inline int ArbolBinarioMonticulo<T>::contarNodoArbols(int pos)
{
	if (vec[pos].getPresente() == false)
	{
		return 0;
	}
	else
	{
		int a, b;
		a = contarNodoArbols(pos * 2);
		b = contarNodoArbols(pos * 2 + 1);
		return a + b + 1;
	}
}
template<class T>
inline int ArbolBinarioMonticulo<T>::contarHojas(int pos)
{
	if (vec[pos].getPresente() == false)
	{
		return 0;
	}
	else
	{
		if (vec[2 * pos].getPresente() == false && vec[2 * pos + 1].getPresente() == false)
		{
			return 1;
		}
		else
		{
			return contarHojas(2 * pos) + contarHojas(2 * pos + 1);
		}
	}
}
template<class T>
bool ArbolBinarioMonticulo<T>::leerArchivo(string nomArch)
{
	int elemento;
	archivo.open(nomArch, ios::in);
	char linea[1024];
	bool res = false;
	while (archivo.fail())
	{
		cout << "Error! No se pudo abrir el archivo" << endl;
		archivo.open(nomArch, ios::in);
		system("cls");
	}
	int i = 0;
	while (!archivo.eof())
	{
		archivo.getline(linea, sizeof(linea));
		elemento = atoi(linea);
		insertar(elemento, raiz);
		i++;
		res = true;
	}
	archivo.close();
	cout << "CANTIDAD DE PALABRAS LEIDAS: " << i << endl;
	return res;
}
template<class T>
NodoArbol<T> ArbolBinarioMonticulo<T>::getRaiz()
{
	return vec[raiz];
}
template<class T>
NodoArbol<T> ArbolBinarioMonticulo<T>::sacarRaiz()
{
	NodoArbol<T> mayor;
	if (vec[1].getPresente() == false)
	{
		mayor.setPresente(false);
	}
	else
	{
		mayor.setElemento(vec[1].getElemento());
		mayor.setVerticeOrigen(vec[1].getVerticeOrigen());
		mayor.setVerticeDestino(vec[1].getVerticeDestino());
		vec[1].setElemento(vec[ultimaHoja].getElemento());
		vec[1].setVerticeOrigen(vec[ultimaHoja].getVerticeOrigen());
		vec[1].setVerticeDestino(vec[ultimaHoja].getVerticeDestino());
		vec[ultimaHoja].setPresente(false);
		ultimaHoja = ultimaHoja - 1;
		recuperarArribaAbajo(1);
	}
	return mayor;
}
template<class T>
inline void ArbolBinarioMonticulo<T>::menu()
{
	int op;
	T elem;
	do
	{
		system("cls");
		cout << "1.Insertar" << endl;
		cout << "2.Recorrer" << endl;
		cout << "3.Contar NodoArbols" << endl;
		cout << "4.Calcular Altura" << endl;
		cout << "5.Eliminar Mayor" << endl;
		cout << "6.Contar Hojas" << endl;
		cout << "7.Leer Archivo" << endl;
		cout << "8.Ordenar" << endl;
		cout << "0.Salir" << endl;
		cin >> op;
		switch (op)
		{
		case 1:
			cout << "Ingrese el Elemento" << endl;
			cin >> elem;
			insertar(elem, raiz);
			break;
		case 2:
			cout << "1.Recorrer InOrder" << endl;
			cout << "2.Recorrer PreOrder" << endl;
			cout << "3.Recorrer PostOrder" << endl;
			cin >> op;
			switch (op)
			{
			case 1:
				cout << "RECORRIDO INORDER" << endl;
				recorrerInOrder(raiz);
				cout << endl;
				break;
			case 2:
				cout << "RECORRIDO PREORDER" << endl;
				recorrerPreOrder(raiz);
				cout << endl;
				break;
			case 3:
				cout << "RECORRIDO POSTORDER" << endl;
				recorrerPostOrder(raiz);
				cout << endl;
				break;
			default: cout << "Error! Elija la opcion correcta" << endl;
			}
			break;
		case 3:
			cout << "Cantidad de NodoArbols: " << contarNodoArbols(raiz) << endl;
			break;
		case 4:
			cout << "La Altura es: " << calcularAltura(raiz) << endl;
			break;
		case 5:
			cout << "Eliminado: " << eliminarMayor(raiz) << endl;
			break;
		case 6:
			cout << "Cantidad de Hojas: " << contarHojas(raiz) << endl;
			break;
		case 7:
			if (leerArchivo("10000 Numeros.txt"))
				cout << "Archivo leido correctamente" << endl;
			else
				cout << "Error! al leer el archivo" << endl;
			break;
		case 8:
			ordenar2(raiz);
			break;
		}
		system("pause");
	} while (op != 0);
}
template<class T>
void ArbolBinarioMonticulo<T>::ordenar(int pos)
{
	NodoArbol<T> vecOrdenado[TAM];
	for (int i = 1; i <= 10000; i++)
	{
		vecOrdenado[i].setElemento(eliminarMayor(raiz));
		vecOrdenado[i].setPresente(true);
		cout << vecOrdenado[i].getElemento() << " ";
	}
	cout << endl;
}
template<class T>
void ArbolBinarioMonticulo<T>::ordenar2(int pos)
{
	vector<int> vecOrdenado;
	for (unsigned i = 0; i <10000; i++)
	{
		vecOrdenado.push_back(eliminarMayor(raiz));
		cout << vecOrdenado[i] << " ";
	}
	cout << endl;
}
/*template<class T>
void ArbolBinarioMonticulo<T>::mostrarOrdenado(int pos)
{
if (vecOrdenado[pos].getPresente() != false)
{
cout << vecOrdenado[pos].getElemento() << " ";
}
}*/