#pragma once
#include"Vertice.h"
#include"ArbolBinarioMonticulo.h"
#include<fstream>
#include<vector>
#define TAM 300
template<class T>
class Grafo
{
private:
	Vertice<T> vec[TAM];
	Lista8<T> cola;
	fstream archivo;
public:
	Grafo();
	~Grafo();
	void inicializar();
	void inicializarKruskal();
	void insertar(T vertice1, T vertice2,int peso);
	void insertarSimple(T vertice1, T vertice2,int peso);
	void insertarNombre(T vertice1, string nombre);
	void mostrarTodo();
	bool busquedaAmplitud(T origen, T destino);
	bool busquedaProfundidad(T origen, T destino);
	void mostrarCamino(int origen, int destino);
	void dijkstra(T origen);
	void mostrarDijkstra(int origen, int destino);
	T buscarCiclo(T x);
	Grafo<T>* kruskal(int &total);
	void mostrarKruskal();
	void menu();
};
template<class T>
Grafo<T>::Grafo()
{

}
template<class T>
Grafo<T>::~Grafo()
{

}
template<class T>
void Grafo<T>::inicializar()
{
	for (int i = 0; i < TAM; i++)
	{
		vec[i].setMarca(false);
		vec[i].setPadre(-1);
	}

}
template<class T>
void Grafo<T>::inicializarKruskal()
{
	for (int i = 0; i < TAM; i++)
	{
		vec[i].setPadre(i);
	}
}
template<class T>
void Grafo<T>::insertar(T vertice1, T vertice2,int peso)
{
		vec[vertice1].setNombre(vertice1);
		vec[vertice1].setExiste(true);
		vec[vertice1].insertarFinalLista8(vertice2,peso);

		vec[vertice2].setNombre(vertice2);
		vec[vertice2].setExiste(true);
		vec[vertice2].insertarFinalLista8(vertice1,peso);

}
template<class T>
void Grafo<T>::insertarSimple(T vertice1, T vertice2,int peso)
{

	vec[vertice1].setNombre(vertice1);
	vec[vertice1].setExiste(true);
	vec[vertice1].insertarFinalLista8(vertice2,peso);
	
}
template<class T>
void Grafo<T>::insertarNombre(T vertice1, string nombre)
{
	vec[vertice1].setNombreDep(nombre);
}
template<class T>
void Grafo<T>::mostrarTodo()
{
	for (int i = 0; i < TAM; i++)
	{
		if (vec[i].getExiste() != false)
		{
			char c = vec[i].getNombre();
			cout << "Vertice: "<< c << endl;
			cout << "Adyacentes:" << endl;
			vec[i].mostrarLista8();
		}
	}
}
template<class T>
bool Grafo<T>::busquedaAmplitud(T origen, T destino)
{
	bool encontre=false;
	vec[origen].setMarca(true);
	cola.insertarFinal(origen,0);
	while (cola.getExiste() != false && encontre == false)
	{
		int i_esimo = 1;
		Nodo<T>*adyacente=new Nodo<T>;
		T vertice = cola.getPrimero()->getElem();
		cola.eleminarPrincipio();
		adyacente = vec[vertice].sacarSiguienteAdyacente(i_esimo);
		while (adyacente != NULL && encontre == false)
		{
			if (vec[adyacente->getElem()].getMarca() == false)
			{
				vec[adyacente->getElem()].setPadre(vertice);
				if (adyacente->getElem() == destino)
					encontre = true;
				else
				{
					vec[adyacente->getElem()].setMarca(true);
					cola.insertarFinal(adyacente->getElem(),0);
				}
			}
			i_esimo++;
			adyacente=vec[vertice].sacarSiguienteAdyacente(i_esimo);
		}
	}
	return encontre;
}
template<class T>
bool Grafo<T>::busquedaProfundidad(T origen, T destino)
{
	bool encontre = false;
	vec[origen].setMarca(true);
	int i_esimo = 1;
	Nodo<T>*adyacente=vec[origen].sacarSiguienteAdyacente(i_esimo);
	while (adyacente != NULL)
	{
		if (encontre == false && vec[adyacente->getElem()].getMarca() == false)
		{
			vec[adyacente->getElem()].setPadre(origen);
			if (adyacente->getElem() == destino)
				encontre = true;
			else
				encontre=busquedaProfundidad(adyacente->getElem(), destino);

		}
		i_esimo++;
		adyacente= vec[origen].sacarSiguienteAdyacente(i_esimo);
	}
	return encontre;
}
template<class T>
void Grafo<T>::mostrarCamino(int origen, int destino)
{
	int aux = destino;
	while (aux != origen)
	{
		cout << aux << " <- ";
		aux = vec[aux].getPadre();
	}
	cout << origen << endl;
}

template<class T>
void Grafo<T>::dijkstra(T origen)
{
	ArbolBinarioMonticulo<int> colaP;
	NodoArbol<int> duo;
	Nodo<T>*adyacente;
	int vertice;
	vec[origen].setDistancia(0);
	colaP.insertar(vec[origen].getDistancia(), origen,0);
	while (colaP.getRaiz().getPresente() != false)
	{
		duo = colaP.sacarRaiz();
		vertice = duo.getVerticeOrigen();
		if (vec[vertice].getMarca() == false)
		{
			vec[vertice].setMarca(true);
			adyacente=vec[vertice].sacarSiguienteAdyacente(1);
			while (adyacente != NULL)
			{
				if (vec[adyacente->getElem()].getMarca() == false && adyacente->getPeso() > 0)
				{
					if (vec[vertice].getDistancia() + adyacente->getPeso() < vec[adyacente->getElem()].getDistancia())
					{
						vec[adyacente->getElem()].setDistancia(vec[vertice].getDistancia() + adyacente->getPeso());
						vec[adyacente->getElem()].setPadre(vertice);
						colaP.insertar(vec[adyacente->getElem()].getDistancia(), adyacente->getElem(),0);
					}
				}
				adyacente = adyacente->getSiguiente();
			}
		}
	}
}
template<class T>
void Grafo<T>::mostrarDijkstra(int origen, int destino)
{
	vector<string> cam;
	if (vec[destino].getMarca() != false)
	{
		while (destino != origen)
		{
			cam.push_back(vec[destino].getNombreDep());
			destino = vec[destino].getPadre();
		}
		cout <<vec[origen].getNombreDep();

		while (!cam.empty())
		{
			cout << "-" << cam.back();
			cam.pop_back();
		}
		cout << endl;
	}
}
template<class T>
T Grafo<T>::buscarCiclo(T x)
{
	while (x != vec[x].getPadre())
	{
		x = vec[x].getPadre();
	}
	return x;
}
template<class T>
Grafo<T>* Grafo<T>::kruskal(int &total)
{
	Grafo<T>* AE= new Grafo<T>;
	ArbolBinarioMonticulo<int> colaP;
	int cont = 0,cantNodos=0,verticeOrigen,verticeDestino;
	NodoArbol<int>trio;
	for (int i = 0; i < TAM; i++)
	{
		if (vec[i].getExiste() == true)
		{
			Nodo<T>*adyacente=vec[i].sacarSiguienteAdyacente(1);
			while (adyacente != NULL)
			{
				colaP.insertar(adyacente->getPeso(), i, adyacente->getElem());
				cantNodos++;
				adyacente = adyacente->getSiguiente();
			}
		}
	}
	while (cont < cantNodos)
	{
		trio = colaP.sacarRaiz();
		verticeOrigen = buscarCiclo(trio.getVerticeOrigen());
		verticeDestino = buscarCiclo(trio.getVerticeDestino());
		if (verticeOrigen != verticeDestino)
		{
			AE->insertar(trio.getVerticeOrigen(), trio.getVerticeDestino(), trio.getElemento());
			total = total + trio.getElemento();
			vec[verticeOrigen].setPadre(vec[verticeDestino].getPadre());
		}
		cont++;
	}
	return AE;
}
template<class T>
void Grafo<T>::mostrarKruskal()
{
	int total=0;
	Grafo<T>*AE = kruskal(total);
	cout << "Costo minimo: " << total << endl;
	AE->mostrarTodo();
}
template<class T>
void Grafo<T>::menu()
{
	int op,total=0,peso;
	fstream archEntrada; 
	char origen, destino; 
	do
	{
		//system("cls");
		cout << "---MENU---"<<endl;
		cout << "1. Insertar arista"<<endl;
		cout << "2. Mostrar Todo"<<endl;
		cout << "3. Busqueda en Amplitud"<<endl;
		cout << "4. Busqueda en Profundidad"<<endl;
		cout << "5. Mostra Camino Destino al Origen"<<endl;
		cout << "8. Dijkstra"<<endl;
		cout << "9. Mostrar Dijkstra"<<endl;
		cout << "10.Kruskal"<<endl;
		cout << "11.Leer Archivo"<<endl;
		cout << "12. Salir"<<endl;
		cin >> op;
		char o, d;
		switch (op)
		{
		case 1:
			cout << "Ingrese el origen: ";
			cin >> o;
			cout << "Ingrese el destino: ";
			cin >> d;
			cout << "Ingrese el peso: ";
			cin >> peso;
			insertar(o, d,peso);
			break;
		case 2:
			mostrarTodo();
			break;
		case 3:
			cout << "Ingrese el origen: ";
			cin >> o;
			cout << "Ingrese el destino: ";
			cin >> d;
			inicializar();
			if (busquedaAmplitud(o, d))
				cout << "Camino Encontrado" << endl;
			else
				cout << "Camino no existe" << endl;
			break;
		case 4:
			cout << "Ingrese el origen: ";
			cin >> o;
			cout << "Ingrese el destino: ";
			cin >> d;
			inicializar();
			if (busquedaProfundidad(o, d))
				cout << "Camino encontrado\n";
			else
				cout << "Camino no encontrado\n";
			break;
		case 5:
			cout << "Ingrese el origen: ";
			cin >> o;
			cout << "Ingrese el destino: ";
			cin >> d;
			mostrarCamino(o, d);
			break;
		case 8:
			cout << "Ingrese el origen: ";
			cin >> o;
			inicializar();
			dijkstra(o);
			break;
		case 9:
			cout << "Ingrese el origen: ";
			cin >> o;

			for (int i = 0; i < TAM; i++)
			{
				if(vec[i].getExiste()!=false)
					mostrarDijkstra(o, i);
			}
			break;
		case 10:
			inicializarKruskal();
			mostrarKruskal();
			break;
		case 11:
			archEntrada.open("grafo_3.txt");
            while (!archEntrada.eof() && archEntrada >> origen >> destino >> peso)
            { 
                insertar(origen, destino, peso);
            }
       	 	archEntrada.close();
		}

	} while (op != 12);
}

