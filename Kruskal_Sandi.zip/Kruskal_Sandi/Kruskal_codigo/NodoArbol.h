#pragma once
#include<iostream>
using namespace std;
template<class T>
class NodoArbol
{
private:
	T elemento;
	bool presente;
	T verticeOrigen;
	T verticeDestino;
public:
	NodoArbol();
	~NodoArbol();
	T getElemento();
	bool getPresente();
	void setElemento(T elemento);
	void setPresente(bool presente);
	void setVerticeOrigen(T verticeOrigen);
	void setVerticeDestino(T verticeDestino);
	T getVerticeOrigen();
	T getVerticeDestino();
};
template<class T>
NodoArbol<T>::NodoArbol()
{
	presente = false;
}
template<class T>
NodoArbol<T>::~NodoArbol()
{

}
template<class T>
T NodoArbol<T>::getElemento()
{
	return elemento;
}
template<class T>
bool NodoArbol<T>::getPresente()
{
	return presente;
}
template<class T>
void NodoArbol<T>::setElemento(T elemento)
{
	this->elemento = elemento;
}
template<class T>
void NodoArbol<T>::setPresente(bool presente)
{
	this->presente = presente;
}
template<class T>
void NodoArbol<T>::setVerticeDestino(T verticeDestino)
{
	this->verticeDestino = verticeDestino;
}
template<class T>
void NodoArbol<T>::setVerticeOrigen(T verticeOrigen)
{
	this->verticeOrigen = verticeOrigen;
}
template<class T>
T NodoArbol<T>::getVerticeOrigen()
{
	return verticeOrigen;
}
template<class T>
T NodoArbol<T>::getVerticeDestino()
{
	return verticeDestino;
}