#pragma once
#include"Nodo.h"
template<class T>
class Lista8
{
private:
	int cont;
	Nodo<T>*primero;
	Nodo<T>*ultimo;
	bool existe;
public:
	Lista8();
	~Lista8();
	void insertarPrincipio(T nuevo);
	void insertarFinal(T nuevo,int peso);
	void insertarLugar(T nuevo);
	void eleminarPrincipio();
	void eleminarFinal();
	void eliminarElementoPosicion(T nuevo);
	void mostrar();
	int contarElementos();
	void menu();
	void invertir();
	void invertir2();
	void buscar(T nuevo);
	Nodo<T>* getPrimero();
	bool getExiste();
	Nodo<T>* sacarSiguienteAdyacente(int i_esimo);
};
template<class T>
Lista8<T>::Lista8()
{
	cont = 0;
	primero = NULL;
	ultimo = NULL;
	existe = false;
}
template<class T>
Lista8<T>::~Lista8()
{

}
template<class T>
void Lista8<T>::insertarPrincipio(T nuevo)
{
	cont++;
	if (primero == NULL)
	{
		primero = new Nodo<T>;
		ultimo = primero;
		primero->setElemento(nuevo);
		existe = true;
	}
	else
	{
		Nodo<T>* aux;
		aux = new Nodo<T>;
		aux->setSiguiente(primero);
		primero->setAnterior(aux);
		aux->setElemento(nuevo);
		primero = aux;
	}
}
template<class T>
void Lista8<T>::insertarFinal(T nuevo,int peso)
{
	cont++;
	if (primero == NULL)
	{
		primero = new Nodo<T>;
		ultimo = primero;
		primero->setElemento(nuevo);
		primero->setPeso(peso);
		existe = true;
	}
	else
	{
		Nodo<T>*aux = new Nodo<T>;
		aux->setAnterior(ultimo);
		aux->setElemento(nuevo);
		aux->setPeso(peso);
		ultimo->setSiguiente(aux);
		ultimo = aux;
	}
}
template<class T>
void Lista8<T>::insertarLugar(T nuevo)
{
	cont++;
	if (primero == NULL)
	{
		insertarPrincipio(nuevo);
	}
	else
	{
		if (nuevo <= primero->getElem())
			insertarPrincipio(nuevo);
		else
		{
			if (nuevo >= ultimo->getElem())
				insertarFinal(nuevo);
			else
			{
				Nodo<T>* aux = new Nodo<T>;
				Nodo<T>*nodo = new Nodo<T>;
				aux = primero;
				while (aux->getSiguiente() != NULL)
				{
					if (nuevo <= aux->getSiguiente()->getElem())
					{
						nodo->setElemento(nuevo);
						nodo->setSiguiente(aux->getSiguiente());
						nodo->setAnterior(aux);
						aux->getSiguiente()->setAnterior(nodo);
						aux->setSiguiente(nodo);
						break;
					}
					else
						aux = aux->getSiguiente();
				}
			}
		}
	}
}
template<class T>
void Lista8<T>::eleminarPrincipio()
{
	if (primero == NULL)
		cout << "Lista Vacia" << endl;
	else
	{
		Nodo<T>* aux = new Nodo<T>;
		if (primero != ultimo)
		{
			aux = primero;
			cont--;
			primero = aux->getSiguiente();
			primero->setAnterior(NULL);
		}
		else
		{
			primero->setSiguiente(NULL);
			delete primero;
			primero = NULL;
			cont = 0;
			existe = false;
		}
	}
}
template<class T>
void Lista8<T>::eleminarFinal()
{
	if (primero == NULL)
		cout << "Lista Vacia" << endl;
	else
	{
		Nodo<T>*aux = new Nodo<T>;
		if (primero != ultimo)
		{
			aux = ultimo;
			ultimo = NULL;
			cont--;
			ultimo = aux->getAnterior();
			ultimo->setSiguiente(NULL);
		}
		else
		{
			ultimo->setAnterior(NULL);
			delete ultimo;
			primero = NULL;
			ultimo = NULL;
			cont = 0;
			existe = false;
		}
	}
}
template<class T>
void Lista8<T>::eliminarElementoPosicion(T nuevo)
{
	if (primero == NULL)
		cout << "Lista vacia" << endl;
	else
	{
		if (nuevo == primero->getElem())
			eleminarPrincipio();
		else
		{
			if (nuevo == ultimo->getElem())
				eleminarFinal();
			else
			{
				Nodo<T>*actual;
				//Nodo<T>*aux ;
				actual = primero->getSiguiente();
				while (actual != NULL && actual != ultimo)
				{
					if (nuevo == actual->getElem())
					{
						//aux = actual;
						actual->getAnterior()->setSiguiente(actual->getSiguiente());
						actual->getSiguiente()->setAnterior(actual->getAnterior());
						delete actual;
						//actual->getSiguiente()->getAnterior()->setSiguiente(NULL);
						//delete actual;
						//actual->setSiguiente(aux);
						//actual->setAnterior(NULL);
						cont--;
						actual = ultimo;
					}
					else
					{
						actual = actual->getSiguiente();
					}
				}
			}
		}
	}
}
template<class T>
void Lista8<T>::mostrar()
{
	Nodo<T>*actual;
	actual = primero;
	if (actual != NULL)
	{
		while (actual != NULL)
		{	
			char elementoChar = actual->getElem();

			cout << elementoChar<<"  Peso: "<<actual->getPeso() << endl;
			actual = actual->getSiguiente();
		}
	}
	else
		cout << "Lista vacia" << endl;

}
template<class T>
int Lista8<T>::contarElementos()
{
	return cont;
}
template<class T>
void Lista8<T>::buscar(T nuevo)
{
	Nodo<T>*actual;
	Nodo<T>*aux = new Nodo<T>;
	bool estado = false;
	actual = primero;
	while (actual != NULL)
	{
		if (actual->getElem() == nuevo)
		{
			aux = actual;
			estado = true;
			actual = NULL;
		}
		else
			actual = actual->getSiguiente();
	}
	if (estado == true)
		cout << aux->getElem() << endl;
	else
		cout << "El elemento no existe" << endl;

}
template<class T>
inline Nodo<T>* Lista8<T>::getPrimero()
{
	return primero;
}
template<class T>
void Lista8<T>::menu()
{
	int op;
	T elemento;

	do
	{
		system("cls");
		cout << "---MENU---\n\n";
		cout << "1. Insertar Principio\n";
		cout << "2. Insertar Final\n";
		cout << "3. Insertar en su lugar\n";
		cout << "4. eliminar principio\n";
		cout << "5. eliminar final\n";
		cout << "6. eliminar elemento de posicion\n";
		cout << "7. mostrar\n";
		cout << "8. mostrar numero de elementos\n";
		cout << "9. Invertir\n";
		cout << "10.buscar\n";
		cout << "0. Salir\n";
		cin >> op;
		switch (op)
		{
		case 1:
			cout << "Ingrese el elemento\n";
			cin >> elemento;
			insertarPrincipio(elemento);
			break;
		case 2:
			cout << "Ingrese el elemento\n";
			cin >> elemento;
			insertarFinal(elemento);
			break;
		case 3:
			cout << "Ingrese el elemento\n";
			cin >> elemento;
			insertarLugar(elemento);
			break;
		case 4:
			eleminarPrincipio();
			break;
		case 5:
			eleminarFinal();
			break;
		case 6:

			cout << "Ingrese elemento a elminar" << endl;
			cin >> elemento;
			eliminarElementoPosicion(elemento);
			break;
		case 7:
			mostrar();
			break;
		case 8:
			cout << "Numero de elementos: " << contarElementos() - 1 << endl;
			break;
		case 9:
			invertir();
			break;
		case 10:
			cout << "Ingrese elemento a buscar" << endl;
			cin >> elemento;
			buscar(elemento);
			break;
		}
		system("pause");
	} while (op != 0);
}
template<class T>
void Lista8<T>::invertir()
{
	if (primero == NULL)
	{
		cout << "Lista vacia" << endl;
	}
	else
	{
		Nodo<T>*aux;
		Nodo<T>*aux2;
		T elemento;
		aux = primero;
		int cant = 0;
		aux2 = primero;
		while (aux != NULL)
		{
			elemento = aux->getElem();
			insertarPrincipio(elemento);
			cant++;
			aux = aux->getSiguiente();

		}
		for (int i = 0; i < cant; i++)
		{
			eleminarFinal();
		}
	}
}
template<class T>
void Lista8<T>::invertir2()
{
	Nodo<T>*aux = new Nodo<T>;
	Nodo<T>*aux2 = new Nodo<T>;
	T elemento;
	if (primero == NULL)
	{
		cout << "Lista vacia" << endl;
	}
	else
	{
		cout << cont << endl;
		aux = primero;
		aux2 = ultimo;
		for (int i = 0; i < (cont / 2); i++)
		{
			if (cont / 2 > 1 && cont / 2 < 1)
			{
				elemento = primero->getElem();
				primero->setElemento(ultimo->getElem());
				ultimo->setElemento(elemento);
			}
			else
			{
				elemento = primero->getElem();
				primero->setElemento(ultimo->getElem());
				ultimo->setElemento(primero->getElem());
				aux = aux->getSiguiente();
				elemento = aux->getElem();
				aux->setElemento(aux2->getAnterior()->getElem());
				aux2 = aux2->getAnterior();
				aux2->setElemento(elemento);
			}
		}
	}
}
template<class T>
bool Lista8<T>::getExiste()
{
	return existe;
}
template<class T>
Nodo<T>* Lista8<T>::sacarSiguienteAdyacente(int i_esimo)
{
	Nodo<T>*aux = primero;
	if (i_esimo > 1)
	{
		for (int i = 1; i < i_esimo; i++)
		{
			aux = aux->getSiguiente();
		}
	}
	return aux;
}